var searchData=
[
  ['cantidad_5fmemoria_5flibre_13',['cantidad_memoria_libre',['../classProcesador.html#a60271654f3a23ebfb885ad3887900cb2',1,'Procesador']]],
  ['cluster_14',['Cluster',['../classCluster.html',1,'Cluster'],['../classCluster.html#aee7feb1d599d4c8fda6c3ee83e86ba81',1,'Cluster::Cluster()']]],
  ['cluster_2ecc_15',['Cluster.cc',['../Cluster_8cc.html',1,'']]],
  ['cluster_2ehh_16',['Cluster.hh',['../Cluster_8hh.html',1,'']]],
  ['colocados_17',['colocados',['../structAreadeespera_1_1contenido.html#adc39a813deb3c9f82f1c61aebd8d7b2b',1,'Areadeespera::contenido']]],
  ['compactar_18',['compactar',['../classProcesador.html#aab3473fe8c42d9199b7947f084a4a582',1,'Procesador']]],
  ['compactar_5fmemoria_5fcluster_19',['compactar_memoria_cluster',['../classCluster.html#a7b9ae511df4a6465f4e191df6564fd77',1,'Cluster']]],
  ['compactar_5fmemoria_5fprocesador_20',['compactar_memoria_procesador',['../classCluster.html#a0cd76c9e5d441abfdf33aba23d1b886e',1,'Cluster']]],
  ['configurar_5fcluster_21',['configurar_cluster',['../classCluster.html#a84f9daea57e2773ab5766ef82d2a1def',1,'Cluster']]],
  ['contenido_22',['contenido',['../structAreadeespera_1_1contenido.html',1,'Areadeespera']]],
  ['contiene_5fproceso_23',['contiene_proceso',['../classProcesador.html#a6386a02534193acaa9f3870743e6a69b',1,'Procesador']]]
];
