var searchData=
[
  ['baja_5fprioridad_98',['baja_prioridad',['../classAreadeespera.html#a04736507a6741012e09997071be7f9f1',1,'Areadeespera']]],
  ['baja_5fproceso_5fprocesador_99',['baja_proceso_procesador',['../classCluster.html#a4ba722e407137beba8fd4733a0f803fd',1,'Cluster']]]
];
