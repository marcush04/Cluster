var searchData=
[
  ['main_50',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['memoria_5focupada_51',['memoria_ocupada',['../classProceso.html#ac748e5053b83097f4071e007737b457a',1,'Proceso']]],
  ['memoria_5fque_5focupa_52',['memoria_que_ocupa',['../classProceso.html#a730b6d80fc76af616de27d170dc00254',1,'Proceso']]],
  ['memoria_5frestante_53',['memoria_restante',['../classProcesador.html#a4f7d8c1bb60aaf176f8b11da9f38ae1e',1,'Procesador']]],
  ['modificar_5fcluster_54',['modificar_cluster',['../classCluster.html#aedab4ad066cb32b6505bcc784c4025f4',1,'Cluster']]],
  ['modificar_5ftiempo_5frestante_55',['modificar_tiempo_restante',['../classProceso.html#a2b8673db99c95b0296f4f6a0ecd62357',1,'Proceso']]]
];
