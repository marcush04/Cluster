var searchData=
[
  ['hay_5fprocesos_5fpendientes_34',['hay_procesos_pendientes',['../classAreadeespera.html#a3bfe585f6e53dda183da3b14dea3944e',1,'Areadeespera']]]
];
