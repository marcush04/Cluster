var searchData=
[
  ['tiempo_151',['tiempo',['../classProceso.html#a23541aa8fe702c686a760c378a1b00d2',1,'Proceso']]],
  ['tiempo_5frestante_152',['tiempo_restante',['../classProceso.html#aef3f2ad47d51eebd8519107108b49cf8',1,'Proceso']]]
];
