var searchData=
[
  ['id_5fpos_5fmemoria_140',['id_pos_memoria',['../classProcesador.html#ab061970c1c14832428ca018de30fbfbe',1,'Procesador']]],
  ['identificador_5fproceso_141',['identificador_proceso',['../classProceso.html#af81a76d4845f8202ca7422fe12c9539d',1,'Proceso']]]
];
