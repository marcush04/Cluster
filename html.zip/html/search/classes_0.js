var searchData=
[
  ['areadeespera_75',['Areadeespera',['../classAreadeespera.html',1,'']]]
];
