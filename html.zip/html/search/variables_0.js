var searchData=
[
  ['colocados_138',['colocados',['../structAreadeespera_1_1contenido.html#adc39a813deb3c9f82f1c61aebd8d7b2b',1,'Areadeespera::contenido']]]
];
