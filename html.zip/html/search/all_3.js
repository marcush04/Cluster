var searchData=
[
  ['elimina_5fproceso_5factivo_5fdirecto_24',['elimina_proceso_activo_directo',['../classProcesador.html#a4ac344ff7f3b7e4140d155e6ce80a7fd',1,'Procesador']]],
  ['elimina_5fproceso_5factivo_5ftiempo_25',['elimina_proceso_activo_tiempo',['../classProcesador.html#af32cacbca0df0a6e4bf448e7c336da6f',1,'Procesador']]],
  ['eliminar_5fproceso_5fpendiente_26',['eliminar_proceso_pendiente',['../classAreadeespera.html#a8edb605e929ec1e85d073d9b3897938b',1,'Areadeespera']]],
  ['enviar_5fprocesos_5fcluster_27',['enviar_procesos_cluster',['../classAreadeespera.html#a7d776a7ebdf99b0976f91080eb331212',1,'Areadeespera']]],
  ['es_20una_20simulación_20del_20funcionamiento_20de_20un_20multiprocesador_2e_20cada_20procesador_20tiene_20su_20propia_20memoria_20y_20es_20capaz_20de_20ejecutar_20más_20de_20un_20proceso_20simultáneamente_2e_28',['Es una simulación del funcionamiento de un multiprocesador. Cada procesador tiene su propia memoria y es capaz de ejecutar más de un proceso simultáneamente.',['../index.html',1,'']]],
  ['estructura_5fprocesadores_29',['estructura_procesadores',['../classCluster.html#a4cd3cbb3cbde720c07333f5d5c0aca3b',1,'Cluster']]],
  ['existe_5fprioridad_30',['existe_prioridad',['../classAreadeespera.html#a9ca5b9ae777d5c80dbdcd87e22715e5e',1,'Areadeespera']]],
  ['existe_5fprocesador_31',['existe_procesador',['../classCluster.html#ad20e465fd643b8ef9f7590cb41c7223e',1,'Cluster']]],
  ['existe_5fproceso_32',['existe_proceso',['../classAreadeespera.html#a5752b6183ea28f51cd44860af76b6994',1,'Areadeespera']]]
];
