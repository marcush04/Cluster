var searchData=
[
  ['cantidad_5fmemoria_5flibre_100',['cantidad_memoria_libre',['../classProcesador.html#a60271654f3a23ebfb885ad3887900cb2',1,'Procesador']]],
  ['cluster_101',['Cluster',['../classCluster.html#aee7feb1d599d4c8fda6c3ee83e86ba81',1,'Cluster']]],
  ['compactar_102',['compactar',['../classProcesador.html#aab3473fe8c42d9199b7947f084a4a582',1,'Procesador']]],
  ['compactar_5fmemoria_5fcluster_103',['compactar_memoria_cluster',['../classCluster.html#a7b9ae511df4a6465f4e191df6564fd77',1,'Cluster']]],
  ['compactar_5fmemoria_5fprocesador_104',['compactar_memoria_procesador',['../classCluster.html#a0cd76c9e5d441abfdf33aba23d1b886e',1,'Cluster']]],
  ['configurar_5fcluster_105',['configurar_cluster',['../classCluster.html#a84f9daea57e2773ab5766ef82d2a1def',1,'Cluster']]],
  ['contiene_5fproceso_106',['contiene_proceso',['../classProcesador.html#a6386a02534193acaa9f3870743e6a69b',1,'Procesador']]]
];
