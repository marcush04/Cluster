var searchData=
[
  ['tiempo_5fejecucion_136',['tiempo_ejecucion',['../classProceso.html#ac67c3339fe82b2b24b5c331ab071ebf3',1,'Proceso']]],
  ['tiempo_5fejecucion_5frestante_137',['tiempo_ejecucion_restante',['../classProceso.html#a20780263aa3c63365b5b4e8c374c6679',1,'Proceso']]]
];
