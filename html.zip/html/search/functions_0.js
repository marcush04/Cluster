var searchData=
[
  ['actualizar_5fmemoria_5frestante_5fadd_89',['actualizar_memoria_restante_add',['../classProcesador.html#ad0a39b2f421cedc1172ab46ec17dbf34',1,'Procesador']]],
  ['actualizar_5fmemoria_5frestante_5fsub_90',['actualizar_memoria_restante_sub',['../classProcesador.html#a153867a37142b4d53e34238d4f44d78a',1,'Procesador']]],
  ['agregar_5fproceso_5factivo_91',['agregar_proceso_activo',['../classProcesador.html#a0b48fd17c652508c942e6587e99feb55',1,'Procesador']]],
  ['agujero_5fajustado_92',['agujero_ajustado',['../classCluster.html#a8f4171862f636e6e0de185aa8e2bc554',1,'Cluster']]],
  ['alta_5fprioridad_93',['alta_prioridad',['../classAreadeespera.html#a18652b06d80485dd49de5f1cae1a0c50',1,'Areadeespera']]],
  ['alta_5fproceso_5fespera_94',['alta_proceso_espera',['../classAreadeespera.html#a70b6c16fa1108ebe84ed409561216794',1,'Areadeespera']]],
  ['alta_5fproceso_5fprocesador_95',['alta_proceso_procesador',['../classCluster.html#a9a7730eb919839c971204ea68692876b',1,'Cluster']]],
  ['areadeespera_96',['Areadeespera',['../classAreadeespera.html#ad20296e85fa07b664c001327c9a5e8cd',1,'Areadeespera']]],
  ['avanzar_5ftiempo_97',['avanzar_tiempo',['../classCluster.html#ab3d8f6f2a025aa7c2f3a5a86f6128962',1,'Cluster']]]
];
