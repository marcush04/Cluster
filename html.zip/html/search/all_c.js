var searchData=
[
  ['tiempo_71',['tiempo',['../classProceso.html#a23541aa8fe702c686a760c378a1b00d2',1,'Proceso']]],
  ['tiempo_5fejecucion_72',['tiempo_ejecucion',['../classProceso.html#ac67c3339fe82b2b24b5c331ab071ebf3',1,'Proceso']]],
  ['tiempo_5fejecucion_5frestante_73',['tiempo_ejecucion_restante',['../classProceso.html#a20780263aa3c63365b5b4e8c374c6679',1,'Proceso']]],
  ['tiempo_5frestante_74',['tiempo_restante',['../classProceso.html#aef3f2ad47d51eebd8519107108b49cf8',1,'Proceso']]]
];
