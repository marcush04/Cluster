var searchData=
[
  ['memoria_5fque_5focupa_143',['memoria_que_ocupa',['../classProceso.html#a730b6d80fc76af616de27d170dc00254',1,'Proceso']]],
  ['memoria_5frestante_144',['memoria_restante',['../classProcesador.html#a4f7d8c1bb60aaf176f8b11da9f38ae1e',1,'Procesador']]]
];
