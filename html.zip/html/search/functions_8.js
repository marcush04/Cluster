var searchData=
[
  ['main_128',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['memoria_5focupada_129',['memoria_ocupada',['../classProceso.html#ac748e5053b83097f4071e007737b457a',1,'Proceso']]],
  ['modificar_5fcluster_130',['modificar_cluster',['../classCluster.html#aedab4ad066cb32b6505bcc784c4025f4',1,'Cluster']]],
  ['modificar_5ftiempo_5frestante_131',['modificar_tiempo_restante',['../classProceso.html#a2b8673db99c95b0296f4f6a0ecd62357',1,'Proceso']]]
];
