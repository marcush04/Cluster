var searchData=
[
  ['revisar_5fagujeros_135',['revisar_agujeros',['../classProcesador.html#aa84f776c70d7affa3b107b8106509b69',1,'Procesador']]]
];
