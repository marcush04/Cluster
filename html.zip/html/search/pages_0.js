var searchData=
[
  ['es_20una_20simulación_20del_20funcionamiento_20de_20un_20multiprocesador_2e_20cada_20procesador_20tiene_20su_20propia_20memoria_20y_20es_20capaz_20de_20ejecutar_20más_20de_20un_20proceso_20simultáneamente_2e_153',['Es una simulación del funcionamiento de un multiprocesador. Cada procesador tiene su propia memoria y es capaz de ejecutar más de un proceso simultáneamente.',['../index.html',1,'']]]
];
