var searchData=
[
  ['lista_142',['lista',['../structAreadeespera_1_1contenido.html#a76f80d8e5c307f97a0156fab37aaf9e0',1,'Areadeespera::contenido']]]
];
