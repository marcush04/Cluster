var searchData=
[
  ['size_69',['size',['../classProcesador.html#ad9ae4dadfe4e5faf369da7e962733714',1,'Procesador']]],
  ['size_5fpos_5fmemoria_70',['size_pos_memoria',['../classProcesador.html#a1472430147120e4972d135b808a755ea',1,'Procesador']]]
];
