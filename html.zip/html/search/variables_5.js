var searchData=
[
  ['pos_5fproceso_145',['pos_proceso',['../classProcesador.html#a72d8fda1df622a1868ba85b0d08ad7f8',1,'Procesador']]],
  ['procesadores_146',['procesadores',['../classCluster.html#a0456efea2e21cfeebda8f61669649a59',1,'Cluster']]],
  ['procesos_5fpendientes_147',['procesos_pendientes',['../classAreadeespera.html#a7b8df47d3da2315b8a2f8f14934f388e',1,'Areadeespera']]]
];
