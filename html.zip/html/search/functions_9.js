var searchData=
[
  ['procesador_132',['Procesador',['../classProcesador.html#aacfa2a06c7d44636ecfb0338bebbfa8b',1,'Procesador']]],
  ['procesador_5factivo_133',['procesador_activo',['../classProcesador.html#a70418094c85742f53131ffd640b73fcd',1,'Procesador']]],
  ['proceso_134',['Proceso',['../classProceso.html#a632f57d6ec48e76c80fbeb7734c1148c',1,'Proceso']]]
];
